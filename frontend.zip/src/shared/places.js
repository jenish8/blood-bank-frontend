export const PLACES = 
	[
			{
				id: 0,
				name: 'Ahmedabad',
				image: 'assets/images/123.jpg',
				category: 'Blood collection',
				description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took',
				source: 'ahmedabd.nic.in'
			},{
				id: 1,
				name: 'Ahmedabad',
				image: 'assets/images/123.jpg',
				category: 'Blood collection',
				description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took',
				source: 'ahmedabd.nic.in'
			},{
				id: 2,
				name: 'Bengaluru',
				image: 'assets/images/bengaluru.jpg',
				category: 'Plateau',
				description: 'Known as both the "Garden City" and "The Silicon Valley of India," Bangalore (officially "Bengaluru") is a techie’s paradise, boasting the highest concentration of IT companies in the country. When you’re done geeking out, there are plenty of gardens, museums, natural features, palaces and temples to fill your dance card. Visit Vidhana Soudha, Cubbon Park and the Ulsoor Lake of Bangalore, well known for its beautiful locales and boating facilities. Bangalore is also a major centre of Indian classical music and dance, and of vivid, cutting-edge nightlife.',
				source: 'tripadvisor.in'
			},{
				id: 3,
				name: 'Bhopal',
				image: 'assets/images/bhopal.jpg',
				category: 'Plains',
				description: 'Bhopal is a city in the central Indian state of Madhya Pradesh. Its one of India’s greenest cities. There are two main lakes, the Upper Lake and the Lower Lake. On the banks of the Upper Lake is Van Vihar National Park, home to tigers, lions and leopards. The State Museum has fossils, paintings and rare Jain sculptures. Taj-ul-Masjid is one of Asia’s largest mosques, with white domes, minarets and a huge courtyard.',
				source: 'wikipedia'
			},{
				id: 4,
				name: 'Chennai',
				image: 'assets/images/chennai.jpg',
				category: 'Coastal',
				description: 'Chennai, on the Bay of Bengal in eastern India, is the capital of the state of Tamil Nadu. The city is home to Fort St. George, built in 1644 and now a museum showcasing the city’s roots as a British military garrison and East India Company trading outpost, when it was called Madras. Religious sites include Kapaleeshwarar Temple, adorned with carved and painted gods, and St. Mary’s, a 17th-century Anglican church. ',
				source: 'wikipedia'
			},
	
	];